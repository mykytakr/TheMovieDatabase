//
//  WatchLaterManager.swift
//  The Movie Database
//
//  Created by NIKITA on 22.05.2024.
//

import Foundation

final class WatchLaterManager {
    static let shared = WatchLaterManager()
    
    private let watchLaterMoviesKey = "WatchLaterMovies"
    private let watchLaterSeriesKey = "WatchLaterSeries"

    private init() {}

    // MARK: - Movies

    func addMovieToWatchLater(_ movie: Movie) {
        var watchLaterMovies = getWatchLaterMovies()
        watchLaterMovies.append(movie)
        saveWatchLaterMovies(watchLaterMovies)
    }

    func getWatchLaterMovies() -> [Movie] {
        return loadWatchLaterItems(forKey: watchLaterMoviesKey)
    }

    func removeMovieFromWatchLater(_ movie: Movie) {
        var watchLaterMovies = getWatchLaterMovies()
        watchLaterMovies.removeAll { $0.id == movie.id }
        saveWatchLaterMovies(watchLaterMovies)
    }

    func isMovieInWatchLater(_ movie: Movie) -> Bool {
        return getWatchLaterMovies().contains { $0.id == movie.id }
    }

    // MARK: - Series

    func addSeriesToWatchLater(_ series: TVSeries) {
        var watchLaterSeries = getWatchLaterSeries()
        watchLaterSeries.append(series)
        saveWatchLaterSeries(watchLaterSeries)
    }

    func getWatchLaterSeries() -> [TVSeries] {
        return loadWatchLaterItems(forKey: watchLaterSeriesKey)
    }

    func removeSeriesFromWatchLater(_ series: TVSeries) {
        var watchLaterSeries = getWatchLaterSeries()
        watchLaterSeries.removeAll { $0.id == series.id }
        saveWatchLaterSeries(watchLaterSeries)
    }

    func isSeriesInWatchLater(_ series: TVSeries) -> Bool {
        return getWatchLaterSeries().contains { $0.id == series.id }
    }

    // MARK: - Private Methods

    private func loadWatchLaterItems<T: Codable>(forKey key: String) -> [T] {
        if let savedData = UserDefaults.standard.data(forKey: key),
           let decodedItems = try? JSONDecoder().decode([T].self, from: savedData) {
            return decodedItems
        }
        return []
    }

    private func saveWatchLaterItems<T: Codable>(_ items: [T], forKey key: String) {
        if let encodedData = try? JSONEncoder().encode(items) {
            UserDefaults.standard.set(encodedData, forKey: key)
            NotificationCenter.default.post(name: NSNotification.Name("WatchLaterUpdated"), object: nil)
        }
    }

    private func saveWatchLaterMovies(_ movies: [Movie]) {
        saveWatchLaterItems(movies, forKey: watchLaterMoviesKey)
    }

    private func saveWatchLaterSeries(_ series: [TVSeries]) {
        saveWatchLaterItems(series, forKey: watchLaterSeriesKey)
    }
}


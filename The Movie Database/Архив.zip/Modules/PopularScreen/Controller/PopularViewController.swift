//
//  PopularMoviesViewController.swift
//  The Movie Database
//
//  Created by NIKITA on 21.05.2024.
//

import UIKit

class PopularViewController: UIViewController {
    private let mainView = PopularView()
    private var movies: [Movie] = []
    private var series: [TVSeries] = []
    
    private var isShowingMovies = true
    
    //MARK: - Life Cycle
    override func loadView() {
        super.loadView()
        view = mainView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupTableView()
        fetchPopularMovies()
    }
}

//MARK: -  Actions
extension PopularViewController {
    @objc private func segmentChanged() {
        isShowingMovies = mainView.segmentedControl.selectedSegmentIndex == 0
        if isShowingMovies {
            fetchPopularMovies()
        } else {
            fetchPopularSeries()
        }
    }
}

//MARK: - Private Methods
extension PopularViewController {
    private func fetchPopularMovies() {
        NetworkService.shared.fetchPopularMovies { [weak self] (movies: [Movie]?) in
            guard let self = self else { return }
            self.movies = movies ?? []
            DispatchQueue.main.async {
                self.mainView.tableView.reloadData()
            }
        }
    }
    
    private func fetchPopularSeries() {
        NetworkService.shared.fetchPopularSeries { [weak self] (series: [TVSeries]?) in
            guard let self = self else { return }
            self.series = series ?? []
            DispatchQueue.main.async {
                self.mainView.tableView.reloadData()
            }
        }
    }
    
    private func setupUI() {
        title = "Popular"
        
        mainView.searchController.searchResultsUpdater = self
        navigationItem.searchController = mainView.searchController
        definesPresentationContext = true
        
        // Setup segmented control
        mainView.segmentedControl.selectedSegmentIndex = 0
        mainView.segmentedControl.addTarget(self, action: #selector(segmentChanged), for: .valueChanged)
        mainView.segmentedControl.translatesAutoresizingMaskIntoConstraints = false
    }
    
    private func setupTableView() {
        mainView.tableView.delegate = self
        mainView.tableView.dataSource = self
        mainView.tableView.register(MovieCell.self, forCellReuseIdentifier: "MovieCell")
        mainView.tableView.register(SeriesCell.self, forCellReuseIdentifier: "SeriesCell")
    }
}

//MARK: - UITableViewDataSource, UITableViewDelegate
extension PopularViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return isShowingMovies ? movies.count : series.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
          if isShowingMovies {
              let cell = tableView.dequeueReusableCell(withIdentifier: "MovieCell", for: indexPath) as! MovieCell
              let movie = movies[indexPath.row]
              cell.configure(with: movie)
              return cell
          } else {
              let cell = tableView.dequeueReusableCell(withIdentifier: "SeriesCell", for: indexPath) as! SeriesCell
              if indexPath.row < series.count {
                  let seriesItem = series[indexPath.row]
                  cell.configure(with: seriesItem)
              }
              return cell
          }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if isShowingMovies {
            let movie = movies[indexPath.row]
            let detailVC = DetailViewController()
            detailVC.movie = movie
            navigationController?.pushViewController(detailVC, animated: true)
        } else {
            let series = series[indexPath.row]
            let detailVC = SeriesDetailViewController()
            detailVC.series = series
            navigationController?.pushViewController(detailVC, animated: true)
        }
    }
}

//MARK: - UISearchResultsUpdating
extension PopularViewController: UISearchResultsUpdating {
    func updateSearchResults(for searchController: UISearchController) {
        guard let query = searchController.searchBar.text, !query.isEmpty else {
            if isShowingMovies {
                fetchPopularMovies()
            } else {
                fetchPopularSeries()
            }
            return
        }
        if isShowingMovies {
            searchMovies(query: query)
        } else {
            searchSeries(query: query)
        }
    }
    
    private func searchMovies(query: String) {
        NetworkService.shared.searchMovies(query: query) { [weak self] (movies: [Movie]?) in
            guard let self = self else { return }
            self.movies = movies ?? []
            DispatchQueue.main.async {
                self.mainView.tableView.reloadData()
            }
        }
    }
    
    private func searchSeries(query: String) {
        NetworkService.shared.searchSeries(query: query) { [weak self] (series: [TVSeries]?) in
            guard let self = self else { return }
            self.series = series ?? []
            DispatchQueue.main.async {
                self.mainView.tableView.reloadData()
            }
        }
    }
}



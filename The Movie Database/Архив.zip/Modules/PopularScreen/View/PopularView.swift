//
//  PopularView.swift
//  The Movie Database
//
//  Created by Vova Kolomyltsev on 23.05.2024.
//

import UIKit
import SnapKit

class PopularView: UIView {
    let tableView: UITableView = {
        let obj =  UITableView()
        obj.translatesAutoresizingMaskIntoConstraints = false
        obj.rowHeight = UITableView.automaticDimension
        obj.estimatedRowHeight = 250
        return obj
    }()
    
    let searchController: UISearchController = {
        let obj = UISearchController()
        obj.obscuresBackgroundDuringPresentation = false
        obj.searchBar.placeholder = "Search Movies or Series"
        return obj
    }()
    
    let segmentedControl = UISegmentedControl(items: ["Movies", "Series"])
    
    
    init() {
        super.init(frame: .zero)
        setupUI()
        setupConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        backgroundColor = .white
        addSubview(segmentedControl)
        addSubview(tableView)
    }
    
    private func setupConstraints() {
        segmentedControl.snp.makeConstraints { make in
            make.top.equalTo(safeAreaLayoutGuide.snp.top)
            make.leading.trailing.equalToSuperview().inset(16)
        }
        
        tableView.snp.makeConstraints { make in
            make.top.equalTo(segmentedControl.snp.bottom)
            make.leading.trailing.bottom.equalToSuperview()
        }
    }
    
}

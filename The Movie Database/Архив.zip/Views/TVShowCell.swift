//
//  TVShowCell.swift
//  The Movie Database
//
//  Created by NIKITA on 18.05.2024.
//

import UIKit

//class TVShowCell: UICollectionViewCell {
//    @IBOutlet weak var posterImageView: UIImageView!
//    @IBOutlet weak var titleLabel: UILabel!
//    @IBOutlet weak var overviewLabel: UILabel!
//    @IBOutlet weak var addButton: UIButton!
//
//    func configure(with tvShow: TVShow) {
//        titleLabel.text = tvShow.name
//        overviewLabel.text = tvShow.overview
//        // Load poster image
//    }
//}

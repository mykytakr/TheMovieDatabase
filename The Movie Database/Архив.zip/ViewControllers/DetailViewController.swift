//
//  DetailViewController.swift
//  The Movie Database
//
//  Created by NIKITA on 21.05.2024.
//

import UIKit
import Kingfisher

class DetailViewController: UIViewController {
    var movie: Movie?

    private let posterImageView = UIImageView()
    private let titleLabel = UILabel()
    private let overviewLabel = UILabel()
    private let genreLabel = UILabel()
    private let yearLabel = UILabel()
    private let ratingLabel = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        displayMovieDetails()
    }

    private func setupUI() {
        title = "Movie Details"
        view.backgroundColor = .white
        view.addSubview(posterImageView)
        view.addSubview(titleLabel)
        view.addSubview(overviewLabel)
        view.addSubview(genreLabel)
        view.addSubview(yearLabel)
        view.addSubview(ratingLabel)

        posterImageView.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        overviewLabel.translatesAutoresizingMaskIntoConstraints = false
        genreLabel.translatesAutoresizingMaskIntoConstraints = false
        yearLabel.translatesAutoresizingMaskIntoConstraints = false
        ratingLabel.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            posterImageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            posterImageView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            posterImageView.widthAnchor.constraint(equalToConstant: 100),
            posterImageView.heightAnchor.constraint(equalToConstant: 150),

            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            titleLabel.leadingAnchor.constraint(equalTo: posterImageView.trailingAnchor, constant: 16),
            titleLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),

            overviewLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 16),
            overviewLabel.leadingAnchor.constraint(equalTo: posterImageView.trailingAnchor, constant: 16),
            overviewLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),

            genreLabel.topAnchor.constraint(equalTo: overviewLabel.bottomAnchor, constant: 16),
            genreLabel.leadingAnchor.constraint(equalTo: posterImageView.trailingAnchor, constant: 16),
            genreLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),

            yearLabel.topAnchor.constraint(equalTo: genreLabel.bottomAnchor, constant: 16),
            yearLabel.leadingAnchor.constraint(equalTo: posterImageView.trailingAnchor, constant: 16),
            yearLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),

            ratingLabel.topAnchor.constraint(equalTo: yearLabel.bottomAnchor, constant: 16),
            ratingLabel.leadingAnchor.constraint(equalTo: posterImageView.trailingAnchor, constant: 16),
            ratingLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16)
        ])

        titleLabel.numberOfLines = 0
        overviewLabel.numberOfLines = 0
        genreLabel.numberOfLines = 1
        yearLabel.numberOfLines = 1
        ratingLabel.numberOfLines = 1
    }

    private func displayMovieDetails() {
        guard let movie = movie else { return }

        titleLabel.text = movie.title
        overviewLabel.text = movie.overview
        genreLabel.text = "Genre: \(NetworkService.shared.getGenres(for: movie.genreIds))"
        yearLabel.text = "Year: \(movie.releaseDate?.split(separator: "-").first.map { String($0) } ?? "Unknown Year")"
        ratingLabel.text = "Rating: \(movie.voteAverage != nil ? "\(movie.voteAverage!)/10" : "No Rating")"
        if let posterPath = movie.posterPath {
            let url = URL(string: "https://image.tmdb.org/t/p/w500\(posterPath)")
            posterImageView.kf.setImage(with: url)
        }
    }
}



